---
title: "专栏示例：Biobran入门"
description: "这是一篇示例专栏文章。"
date: "2025-08-19"
tags: ["biobran","immune"]
lang: "zh"
---

这里是正文内容（支持 Markdown）。
